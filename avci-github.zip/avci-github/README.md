# AVCI — Muhasebe

Kişisel finans / alacak takip uygulaması.

## GitHub Pages

Site kökünde `index.html` bulunur.  
**Settings → Pages → Branch: main → / (root)** ile yayınlanır.

Adres örneği: `https://KULLANICI_ADIN.github.io/avci-muhasebe/`
